"""Baseline

Revision ID: 3c5ecfcb5ebe
Revises: 
Create Date: 2021-08-16 22:46:47.496447

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3c5ecfcb5ebe'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
