class NonExistentChatGroup(Exception):
    pass
