class UnexpectedRelationshipState(Exception):
    pass
