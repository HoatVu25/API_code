import { createBrowserHistory } from "history";

// History instance that can be used to arbitrarily edit browser history and navigate to specific routes
export const routerHistory = createBrowserHistory();
