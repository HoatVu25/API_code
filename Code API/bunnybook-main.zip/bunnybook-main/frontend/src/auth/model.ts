export interface User {
  email: string;
  id: string;
  role: string;
  username: string;
  isLogged?: boolean;
}
